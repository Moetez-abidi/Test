// Procedures globales du projet
function PBROWSER_INFIREFOXORNETSCAPEBRW(){try{clWDUtil.Try();{clWDUtil.Renvoyer((!(clWDUtil.oConversionType(clWDUtil.nGetNavigateurType(),8,0,8,0)==0)));return;}}catch(_E){clWDUtil.xbCatchThrow(_E);return;}finally{return clWDUtil&&clWDUtil.oFinally();}}
