// Procedures globales du projet
function Toggle(idObj,idCap)
{
	var iObj, iCap;
	iObj = document.getElementById(idObj);
	iCap = document.getElementById(idCap);
	
	if(iObj.style.display != 'none')
	{ 
		iObj.style.display = 'none';
		iCap.innerText = 'Display';
	}
	else
	{
		iObj.style.display = 'block';
		iCap.innerText = 'Hide';
	}
}

function Input(sText, sDefaultValue)
{
	return window.prompt(sText, sDefaultValue);
}
